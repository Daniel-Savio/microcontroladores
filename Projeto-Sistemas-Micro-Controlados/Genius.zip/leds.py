from machine import Pin
from time import sleep

# LED pins
LED_PINS = [
  Pin(1, Pin.OUT),
  Pin(0, Pin.OUT),
  Pin(2, Pin.OUT),
  Pin(3, Pin.OUT)
]

def blink_single(index, duration=0.25):
  LED_PINS[index].value(1)
  sleep(duration)
  LED_PINS[index].value(0)
  sleep(0.12)

def blink_all(times=2, duration=0.25):
  for _ in range(times):
    set_all(1)
    sleep(duration)
    set_all(0)
    sleep(duration)

def set_all(state):
  for led in LED_PINS:
    led.value(state)

def reset_effect():
  for _ in range(3):
    for led in LED_PINS:
      led.value(1)
      sleep(0.1)
      led.value(0)
      sleep(0.05)
