from time import sleep
from pico_i2c_lcd import I2cLcd

class LCDMessages:

  def __init__(self, i2c, address=0x27, lines=2, columns=16):
    """
    Inicializa um display LCD baseado em I2C.
    Agora o hardware não é fixo! Ele é passado pelo main.py.
    """
    self.lcd = I2cLcd(i2c, address, lines, columns)
    sleep(0.2)

  def lcd_msg(self, line1="", line2=""):
    """Imprime duas linhas no LCD."""
    self.lcd.clear()
    sleep(0.15)

    self.lcd.move_to(0, 0)
    self.lcd.putstr(line1)
    sleep(0.05)

    self.lcd.move_to(0, 1)
    self.lcd.putstr(line2)
    sleep(0.05)

  # ---------------------------
  # Telas padronizadas
  # ---------------------------

  def screen_welcome(self, record):
    self.lcd_msg("Press START", f"Record: {record}")

  def screen_round(self, n):
    self.lcd_msg(f"Round: {n}", "Repeat the seq")

  def screen_fail(self, points):
    self.lcd_msg("You lost!", f"Score: {points}")

  def screen_new_record(self, new_record):
    self.lcd_msg("New Record!", f"Record: {new_record}")

  def screen_rebooting(self):
    self.lcd_msg("Rebooting...", "Please wait")
