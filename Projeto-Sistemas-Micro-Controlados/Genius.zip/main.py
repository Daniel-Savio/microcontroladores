from machine import Pin, I2C
from time import sleep
import urandom

from leds import blink_single, blink_all, reset_effect
from lcd_msgs import LCDMessages

# ------------------------------------------------------
# Custom exception to abort the game instantly
# ------------------------------------------------------
class SoftReset(Exception):
  pass

# ------------------------------------------------------
# LCD init
# ------------------------------------------------------
i2c0 = I2C(0, sda=Pin(16), scl=Pin(17))
display = LCDMessages(i2c0, address=0x27)

# ------------------------------------------------------
# Color buttons
# ------------------------------------------------------
COLOR_BTNS = [
  Pin(5, Pin.IN, Pin.PULL_UP),
  Pin(4, Pin.IN, Pin.PULL_UP),
  Pin(6, Pin.IN, Pin.PULL_UP),
  Pin(7, Pin.IN, Pin.PULL_UP)
]

# ------------------------------------------------------
# Control buttons
# ------------------------------------------------------
BTN_START = Pin(8, Pin.IN, Pin.PULL_UP)
BTN_RESET = Pin(9, Pin.IN, Pin.PULL_UP)

# ------------------------------------------------------
# Game state
# ------------------------------------------------------
record = 0
game_running = False
start_flag = False

# ------------------------------------------------------
# IRQ HANDLERS
# ------------------------------------------------------
def start_irq(pin):
  global start_flag
  sleep(0.02)  # debounce
  if pin.value() == 0:
    start_flag = True

def reset_irq(pin):
  # No flags. RESET agora é imediato via exceção.
  sleep(0.02)
  if pin.value() == 0:
    raise SoftReset()

# ------------------------------------------------------
# Wait for color button
# ------------------------------------------------------
def wait_color_press():
  while True:
    # Pressionar reset dentro dessa função deve abortar tudo
    if BTN_RESET.value() == 0:
      raise SoftReset()

    for i, btn in enumerate(COLOR_BTNS):
      if btn.value() == 0:
        sleep(0.15)
        return i

    sleep(0.01)

# ------------------------------------------------------
# Game logic
# ------------------------------------------------------
def play_game():
  global game_running, record

  game_running = True
  sequence = []
  round_n = 1

  blink_all()

  while True:

    if BTN_RESET.value() == 0:
      raise SoftReset()

    sequence.append(urandom.getrandbits(2))
    display.screen_round(round_n)

    for v in sequence:
      if BTN_RESET.value() == 0:
        raise SoftReset()
      blink_single(v)
      sleep(0.05)

    for expected in sequence:
      press = wait_color_press()
      blink_single(press)

      if press != expected:
        display.screen_fail(round_n - 1)
        sleep(1)

        if round_n - 1 > record:
          record = round_n - 1
          display.screen_new_record(record)
          sleep(1.2)

        blink_all(3)
        game_running = False
        return

    round_n += 1
    sleep(0.25)

# ------------------------------------------------------
# Soft reset handler
# ------------------------------------------------------
def perform_soft_reset():
  global game_running
  game_running = False

  display.screen_rebooting()
  sleep(0.7)

  reset_effect()
  display.screen_welcome(record)

# ------------------------------------------------------
# MAIN LOOP
# ------------------------------------------------------
display.screen_welcome(record)
sleep(0.4)

# IRQs habilitadas APÓS LCD inicializado
BTN_START.irq(trigger=Pin.IRQ_FALLING, handler=start_irq)
BTN_RESET.irq(trigger=Pin.IRQ_FALLING, handler=reset_irq)

while True:

  if start_flag and not game_running:
    start_flag = False

    try:
      play_game()

    except SoftReset:
      perform_soft_reset()
      display.screen_welcome(record)

  sleep(0.01)
