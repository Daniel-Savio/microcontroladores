LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;

ENTITY safe_tb IS
END ENTITY;


ARCHITECTURE testbench OF safe_tb IS

    COMPONENT safe
        PORT (
            a, b, c : IN STD_LOGIC;
            m : OUT STD_LOGIC);
    END COMPONENT;

    SIGNAL a, b, c, m : STD_LOGIC;

	BEGIN

		UUT: safe PORT MAP(a, b, c, m);

		stimulus: PROCESS

		BEGIN
			a <= '0';
        	b <= '0';
			c <= '0';
       		   wait for 10 ns;
            assert (m = '0') report "Teste falhou para 000" severity NOTE;

            a <= '1';
            b <= '0';
            c <= '0';
               wait for 10 ns;
            assert (m = '0') report "Teste falhou para 100" severity NOTE;


            a <= '0';
            b <= '1';
            c <= '0';
               wait for 10 ns;
            assert (m = '0') report "Teste falhou para 010" severity NOTE;

            a <= '0';
            b <= '0';
            c <= '1';
               wait for 10 ns;
            assert (m = '0') report "Teste falhou para 001" severity NOTE;

            a <= '1';
            b <= '0';
            c <= '1';
               wait for 10 ns;
            assert (m = '1') report "Teste falhou para 101" severity NOTE;

            a <= '1';
            b <= '1';
            c <= '0';
               wait for 10 ns;
            assert (m = '1') report "Teste falhou para 110" severity NOTE;

            a <= '0';
            b <= '1';
            c <= '1';
               wait for 10 ns;
            assert (m = '1') report "Teste falhou para 011" severity NOTE;

            a <= '1';
            b <= '1';
            c <= '1';
               wait for 10 ns;
            assert (m = '1') report "Teste falhou para 011" severity NOTE;
			report "Fim da simulacao" severity NOTE;
			wait;


		END PROCESS;

END testbench;