library IEEE;
use IEEE.std_logic_1164.all;

entity safe is
port(a, b, c: in std_logic;
    	 m, cout: out std_logic);
end safe;

architecture behav of safe is
begin
	m <= ((a and b) or (a and c) or (c and b));
end behav;
