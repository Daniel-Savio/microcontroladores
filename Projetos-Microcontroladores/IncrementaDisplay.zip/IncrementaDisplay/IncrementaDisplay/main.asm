;
; IncrementaDisplay.asm
;
; Created: 03/07/2024 21:15:02
; Author : Daniel Savio
;

	.DEF	dezena = R17
	.DEF	unidade = R18

	.ORG	0x00 ;diretiva de in�cio do c�d
	
start:
	LDI		R16,0xFF ;carrega 255 em R16
	OUT		DDRD,R16 ;configura DDRD como sa�da (LEDs)

	LDI		R16,0x00				; carrega 0 em R16
	OUT		PORTD,R16				;desliga o display

	LDI		R16,0xFF				;carrega 255 em R16
	OUT		DDRC,R16				;configura DDRC como sa�da (controle 7-seg)

	LDI		dezena,0
	LDI		unidade,0

	LDI		R16,0x00
	OUT		DDRB, R16
	
	SBI		PORTB,PB0				; alimenta B0
	OUT		MCUCR,R16				; Habilita pullup (PUD - bit5 do MCUCR) 

	.dseg
	.org 0x100
dec_7seg:	.byte 10				;Aloca 10 bytes na RAM
	
	.cseg

; armazenando valores decodificados do display 7 seg (cat comum no inicio da RAM)
	LDI		R16,0x3F
	STS		dec_7seg,R16
	LDI		R16,0x06
	STS		dec_7seg+1,R16
	LDI		R16,0x5B
	STS		dec_7seg+2,R16
	LDI		R16,0x4F
	STS		dec_7seg+3,R16
	LDI		R16,0x66
	STS		dec_7seg+4,R16
	LDI		R16,0x6D
	STS		dec_7seg+5,R16
	LDI		R16,0x7D
	STS		dec_7seg+6,R16
	LDI		R16,0x07
	STS		dec_7seg+7,R16
	LDI		R16,0x7F
	STS		dec_7seg+8,R16
	LDI		R16,0x67
	STS		dec_7seg+9,R16
	LDI		R16,0x77
	STS		dec_7seg+10,R16
	LDI		R16,0x7C
	STS		dec_7seg+11,R16
	LDI		R16,0x39
	STS		dec_7seg+12,R16
	LDI		R16,0x5E
	STS		dec_7seg+13,R16
	LDI		R16,0x79
	STS		dec_7seg+14,R16
	LDI		R16,0x71
	STS		dec_7seg+15,R16

LOOP:								;Estrutura de repeti��o
	SBIC	PINB,PB0				;pula a prox intru��o se o PIND,PD0 for = 0 (PB0 = 0 quando o bot�o esta pressionado)
	RJMP	MULTIPLEXA				;Ser� acionado caso PD0=1 e pulado se PD0=0 (bot�o pressionado? n�o)
	RCALL	BOTAO_PRESS				;Ser� acionado caso PD0=1 e pulado se PD0=0 (bot�o pressionado? sim)
	RJMP	MULTIPLEXA
	RJMP	LOOP

BOTAO_PRESS:
SBIC	PINB,PB0
RJMP	INCREMENTA					;Ser� acionado caso PD0=1 e pulado se PD0=0 (bot�o pressionado? n�o)
RJMP	BOTAO_PRESS					;Ser� acionado caso PD0=1 e pulado se PD0=0 (bot�o pressionado? sim)
INCREMENTA:							;rotina de ++
INC_UNIDADE:
	CPI		unidade,9				;verifica SE unidade == 9
	BREQ	INC_DEZENA				;SE unidade == 9 BREQ vai p INC_DEZENA
	INC		unidade					;SE unidade != 9 unidade++
	RET
INC_DEZENA:
	LDI		unidade,0				;unidade = 9, ent�o unidade++ = unidade = 0  e dezena++
	CPI		dezena,9				;verifica SE dezena == 9
	BREQ	ZERA_DEZENA				;SE dezena = 9, dezena++ = 00
	INC		dezena					; SE dezena != 9 dezena ++
	RET
ZERA_DEZENA:
	LDI		dezena,0
	RET

MULTIPLEXA:
	;Mostra unidade
	CBI		PORTC,PC1
	LDI		ZH,0x01
	LDI		ZL,0x00
	ADD		ZL,unidade
	LD		R0,Z
	OUT		PORTD,R0
	SBI		PORTC,PC2
	RCALL	DELAY

	;Mostra dezena
	CBI		PORTC,PC2
	LDI		ZH,0x01
	LDI		ZL,0x00
	ADD		ZL,dezena
	LD		R0,Z
	OUT		PORTD,R0
	SBI		PORTC,PC1
	RCALL	DELAY
	RJMP	LOOP

DELAY:
	CLR		R21
	CLR		R22
WAIT:
	DEC		R21
	BRNE	WAIT
	DEC		R22
	BRNE	WAIT
	RET